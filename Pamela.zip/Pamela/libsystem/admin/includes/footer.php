<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; 2023 - Library Lending System | Brought To You By <a href="https://code-projects.org/">Pamela Hangoma</a></strong>
</footer>