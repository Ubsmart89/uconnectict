<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b><!--Admin Panel and Add/View user to know Login ID</b-->
      </div>
      <strong>&copy; 2023 - Library Lending System | Brought To You By <a href="https://code-projects.org/">Pamela Hangoma</a></strong>
      </div>
    <!-- /.container -->
</footer>